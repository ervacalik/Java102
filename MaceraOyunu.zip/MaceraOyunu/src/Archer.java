
public class Archer extends GameCharacter {

	public Archer() {
		super("Okçu", 7, 18, 20, 2);

	}

}
