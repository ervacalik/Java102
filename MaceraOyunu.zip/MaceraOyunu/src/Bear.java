
public class Bear extends Obstacle {

	public Bear() {
		super("Ayı", 3, 7, 20, 12);

	}

}
