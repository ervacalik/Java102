
public class Cave extends GameBottleLocation  {

public Cave(Player player) {
		super(player, "Mağara", 3, "Ödül: <Yemek>, dikkatli ol karşıına zombi çıkabilir !" , new Zombie(), "Food",3);
		
	}


	

	

}
