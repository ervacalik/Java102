
public class Forest extends GameBottleLocation{

	public Forest(Player player) {
		super(player, "Orman", 4, "Ödül: <Odun>, dikkatli ol karşıına vampir çıkabilir !",new Vampire(),"Firewood",3);
		
	}
	
	


}
