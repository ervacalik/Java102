
public class Gun extends Weapon{

	public Gun() {
		super("Tabanca",1, 2, 5);
		
	}
	

}
