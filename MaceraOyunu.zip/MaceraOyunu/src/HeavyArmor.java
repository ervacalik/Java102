
public class HeavyArmor extends Armor {

	public HeavyArmor() {
		super("Ağır", 3, 5, 40);
		// TODO Auto-generated constructor stub
	}

}
