
public class Knight extends GameCharacter {

	public Knight() {
		super("Şövalye", 8, 20, 5, 3);
		
	}

}
