
public class LightArmor extends Armor {

	public LightArmor() {
		super("Hafif", 1, 1, 15);
		
	}

}
