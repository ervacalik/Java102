
public class Main {
	public static void main(String[] args) {
		
//		Samurai samurai = new Samurai();
//		System.out.println(samurai.getPara());
//		
//		Okcu okcu =new Okcu();
//		System.out.println(okcu.getSaglik());
//		
//		Sovalye sovalye =new Sovalye();
//		System.out.println(sovalye.getHasar());
		
//		Knight knight=new Knight();
//		System.out.println(knight.getId());
		
		Game game1= new Game();
		game1.start();
		
	}

}
