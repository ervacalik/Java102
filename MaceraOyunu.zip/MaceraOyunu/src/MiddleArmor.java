
public class MiddleArmor extends Armor {

	public MiddleArmor() {
		super("Orta", 2, 3, 25);
		
	}

}
