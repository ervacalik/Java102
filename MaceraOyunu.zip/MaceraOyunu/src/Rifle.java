
public class Rifle extends Weapon {

	public Rifle() {
		super("Tüfek",3, 7, 45);
		
	}
	

}
