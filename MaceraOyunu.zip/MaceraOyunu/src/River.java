
public class River extends GameBottleLocation{

	public River(Player player) {
		super(player, "Nehir", 5,  "Ödül: <Su>, dikkatli ol karşıına ayı çıkabilir !",new Bear(),"Water",2);
		
	}
	

}
