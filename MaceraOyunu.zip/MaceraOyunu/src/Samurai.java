
public class Samurai extends GameCharacter {

	public Samurai() {
		super("Samuray", 5, 21, 15, 1);
	}

}
