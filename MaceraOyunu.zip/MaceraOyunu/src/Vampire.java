
public class Vampire extends Obstacle {

	public Vampire() {
		super("Vampir", 2, 4, 14, 7);

	}

}
