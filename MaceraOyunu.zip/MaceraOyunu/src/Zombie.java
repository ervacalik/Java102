
public class Zombie extends Obstacle {

	public Zombie() {
		super("Zombi", 1, 3, 10, 4);

	}

}
